num1 = 7;
num2 = 5;
sum = num1 + num2;
sub = num1 - num2;
div = num1 / num2;
product = num1 * num2;
exp = num1 ** num2;
remainder = num1 % num2;
newNum1 = ++num1;
newNum2 = --num2;

console.log(`
    ${sum} = num1 + num2;
    ${sub} = num1 - num2;
    ${div} = num1 / num2;
    ${product} = num1 * num2;
    ${exp} = num1 ** num2;
    ${remainder} = num1 % num2;
    ${newNum1} = ++num1;
    ${newNum2} = --num2;`);