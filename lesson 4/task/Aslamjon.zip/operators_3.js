num1 = 7;
num2 = 5;
sum = num1;
sub = num1;
div = num1;
product = num1;
exp = num1;
remainder = num1;

console.log(`
    ${sum += num1} = num1 + num1;
    ${sub -= num1} = num1 - num1;
    ${div /= num1} = num1 / num1;
    ${product *= num1} = num1 * num1;
    ${exp **= num1} = num1 ** num1;
    ${remainder %= num1} = num1 % num1;`);